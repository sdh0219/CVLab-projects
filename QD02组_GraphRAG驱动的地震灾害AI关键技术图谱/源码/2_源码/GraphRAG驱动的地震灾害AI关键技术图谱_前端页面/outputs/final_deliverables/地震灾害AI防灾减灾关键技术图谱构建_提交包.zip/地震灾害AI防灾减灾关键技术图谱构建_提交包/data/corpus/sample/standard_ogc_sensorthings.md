---
doc_id: standard_ogc_sensorthings
title: OGC SensorThings API for seismic sensor observations
source_type: standard
source_name: OGC
source_url: "https://www.ogc.org/standard/sensorthings/"
year: 2021
region: global
disaster_type: 地震
---

# OGC SensorThings API for seismic sensor observations

该标准来源为“OGC SensorThings API for seismic sensor observations”，来源机构或平台为 OGC。在地震灾害AI防灾减灾关键技术图谱中，该来源被整理为 地震 专题证据，主要支撑 地震早期预警 技术社区，并服务 地震早期预警 场景。

从可抽取证据看，地震早期预警 依赖 地震台网数据，常结合 机器学习，用于完成 地震监测预警。该证据可与 ShakeAlert地震预警案例 形成案例验证关系，并受 地震预警发布规范 的治理要求约束。

面向 GraphRAG 索引，可形成“地震早期预警 -> 地震 -> 地震早期预警 -> 地震监测预警 -> 地震台网数据 -> 机器学习 -> ShakeAlert地震预警案例”的证据链。该来源同时提示需要关注 实时部署困难、专家校验和证据可追溯性。

元数据层面，该证据的区域为 global，年份为 2021。本整理稿只保留用于实体、关系和声明抽取的中文摘要，不替代原文引用。
